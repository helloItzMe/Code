///////////////////////////////////////////////////////////////////////////////////////////
//                                                   41 Post                             //
// Android: Bitmap to Integer array                                                      //
// Created by DimasTheDriver in 19/Oct/2011                                      		 //
// Available at:       http://www.41post.com/?p=4396                           		     //
///////////////////////////////////////////////////////////////////////////////////////////
package fortyonepost.com.btia;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

public class BitmapToIntArrayActivity extends Activity 
{	
	//a Bitmap object 
	private Bitmap bmp;
	
	//an array that stores the pixel values
	private int intArray[];
	
	//an ImageView, to render the original image
	private ImageView iv_originalImage;
	//an ImageView, to render the modified image
	private ImageView iv_imageFromArray;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //initialize the ImageView objects using data from the 'layout.xml' file
        iv_originalImage = (ImageView) findViewById(R.id.iv_originalImage);
        iv_imageFromArray = (ImageView) findViewById(R.id.iv_imageFromArray); 
        
        //initialize the Bitmap Object
        bmp = BitmapFactory.decodeResource(getResources(), R.drawable.four_colors);
        //Guarantees that the image is decoded in the ARGB8888 format
        bmp = bmp.copy(Bitmap.Config.ARGB_8888, true);
        
        //draw the Bitmap, unchanged, in the ImageView
        iv_originalImage.setImageBitmap(bmp);
        
        //Initialize the intArray with the same length as the number of pixels on the image
        intArray = new int[bmp.getWidth()*bmp.getHeight()];
        
        //copy pixel data from the Bitmap into the 'intArray' array
        bmp.getPixels(intArray, 0, bmp.getWidth(), 0, 0, bmp.getWidth(), bmp.getHeight());
        
        //replace the red pixels with yellow ones
        for (int i=0; i<intArray.length; i++)
        {
        	if(intArray[i] == 0xFFFF0000)
        	{
        		intArray[i] =  0xFFFFFF00;
        	}
        }
        
        //Initialize the bitmap, with the replaced color
        bmp = Bitmap.createBitmap(intArray, bmp.getWidth(), bmp.getHeight(), Bitmap.Config.ARGB_8888);
        
        //Draw the bitmap with the replaced color
        iv_imageFromArray.setImageBitmap(bmp);
    }
}